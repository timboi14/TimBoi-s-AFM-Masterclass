# AFM Specimen – from September 2022 onwards

## Question 1 (50 marks)

### Exhibit 1 — Kingtim Co

Kingtim Co is a nationwide chain of garden centres, selling products such as plants, fertilisers, tools and garden furniture. It was established 20 years ago by the current team of executive directors, and achieved a listing on its local stock market four years ago. Since listing, the company has made consistent profits and has been able to increase its dividends each year. The executive directors collectively own between them 25% of issued share capital. The remaining shares are held by a number of investors, with none of them owning more than 10% of issued share capital.

Two of Kingtim Co’s major competitors have been taken over in the last two years. Media coverage suggests that further takeovers are possible. Potential acquirers include other chains of garden centres, property developers and supermarket chains looking to diversify their business into the profitable garden centre sector. As yet, no potential acquirer has approached Kingtim Co to buy the whole chain, although Kingtim Co has had enquiries from other businesses wanting to purchase individual garden centres. Kingtim Co can sell a number of individual garden centres without threatening its continued existence.

### Exhibit 2 — Takeover defences

Kingtim Co’s executive directors remain committed to the business. They are fearful of a takeover, believing that the new owners will want some, or all of them, to leave the company. They have therefore been considering possible defences against a takeover bid. Kingtim Co’s chief executive has received two proposals from directors:

- Sell individual garden centres which would be particularly attractive to purchasers. Disposal of these centres would make Kingtim Co, overall, a less attractive purchase.
- Pay the executive directors higher remuneration and change their contracts so that they would receive much higher compensation for loss of office if their contracts were terminated early.

Kingtim Co’s chief executive believes, however, that any defence Kingtim Co adopts should also strengthen the company’s future. She is therefore proposing to expand the company’s current limited sales of camping products in its garden centres by establishing a chain of Kingtim outdoor shops, selling camping, walking and other outdoor equipment. The outdoor retail sector is competitive, but the chief executive believes that Kingtim Co will be successful. The establishment of the chain of outdoor shops would be funded solely by debt, the idea being that changing Kingtim Co’s finance structure by having significantly more debt would make it less attractive to acquirers.

### Exhibit 3 — Financial details

Kingtim Co currently has 25 million $1 shares in issue, with a current share price of $5.56 per share. It also has 0.45 million 6.5% bonds in issue. Each 6.5% bond has a nominal value of $100, and is currently trading at $104 per $100. The premium on redemption of the bonds in three years’ time is 2%. Based on a yield to maturity approach, the after-tax cost of the bonds is 4.1%.

Kingtim Co’s quoted equity beta for its existing garden centre business is 0.9.

Kingtim Co plans to issue 0.6 million, 7.5%, new bonds, each with a nominal value of $100. These bonds will be redeemable in four years’ time at a premium of 8%. The coupon on these bonds will be payable on an annual basis. These bonds are anticipated to have a credit rating of BBB–. The issue of the new 7.5% bonds will not affect the market value of Kingtim Co’s shares or the existing 6.5% bonds.

The market value of the new bonds will be determined by using information relating to Kingtim Co’s credit rating and the four bonds which the government has issued to estimate Kingtim Co’s yield curve. All the bonds are of the same risk class. Details of the bonds are as follows:

| Bond | Annual yield based on spot rate | Redeemable in |
|---|---:|---:|
| Ga | 4.0% | 1 year |
| Th | 4.3% | 2 years |
| De | 4.7% | 3 years |
| Ro | 5.2% | 4 years |

Credit spreads, shown in basis points, are as follows:

| Rating | 1 year | 2 years | 3 years | 4 years |
|---|---:|---:|---:|---:|
| BBB– | 56 | 78 | 106 | 135 |

Kingtim Co plans to invest $60m in non-current assets for the outdoor shops (working capital requirements can be ignored). Currently, Kingtim Co’s non-current assets have a net book value of $150m. It is assumed that the proportion of the book value of non-current assets which will be invested in the outdoor shops and the garden centres will give a fair representation of the size of each business within Kingtim Co. The asset beta of similar companies in the outdoor retail sector is assumed to be 0.88.

Before taking into consideration the impact of this new investment, Kingtim Co’s forecast pre-tax profits for the coming year is $24m. It is estimated that the new investment will make a 10% pre-tax return.

The corporation tax rate applicable to all companies is 25% per year. The current risk-free rate of return is estimated to be 4% and the market risk premium is estimated to be 9%.

### Exhibit 4 — Employee remuneration

Kingtim Co’s annual report contains a general commitment to act with social responsibility, in line with society’s expectations. It also commits to paying its staff fairly in accordance with their responsibilities and states that its staff are vital to its success.

To try to improve the situation of low-paid employees, the government has recommended a basic hourly wage as the minimum level employees should be paid, although this minimum is not legally enforceable. A newspaper investigation has revealed that some staff in Kingtim Co’s garden centres in the northern region of the country are paid up to 15% less per hour than the recommended minimum wage. Most of these staff are part-time staff, working limited hours each week.

The manager of Kingtim Co’s northern region centres, when asked to comment, stated that Kingtim Co had obligations to its shareholders to control staff costs. Lower pay levels were necessary to differentiate between staff, ensuring that managers and staff with experience and expertise were appropriately rewarded. The manager commented that pay levels also reflected the lower commitment to Kingtim Co which part-time staff made compared with full-time staff.

### Requirements (50 marks)

**(a)** Discuss the feasibility and effectiveness of the defence strategies of selling off individual garden centres and enhancing directors’ remuneration. **(7 marks)**

**(b)** Prepare a report for the board of directors of Kingtim Co which:

**(i)** estimates the company’s cost of capital before the new bonds are issued; **(4 marks)**

**(ii)** estimates the market value and post-tax cost of debt of the new bonds; **(7 marks)**

**(iii)** estimates the revised cost of equity and revised cost of capital if the new bonds are issued; **(7 marks)**

**(iv)** discusses the impact on Kingtim Co’s cost of capital and the reaction of equity and bond holders to the chief executive’s proposal. The discussion should include an explanation of any assumptions made in the estimates in (b)(i)–(iii) above. **(9 marks)**

**(c)** Discuss the approach taken to employee remuneration by Kingtim Co’s Northern region and the issues associated with it. **(6 marks)**

Professional marks will be awarded for the demonstration of skill in communication, analysis and evaluation, scepticism and commercial acumen in your answer. **(10 marks)**

---

## Question 2 (25 marks)

### Exhibit 1 — Colvin Co

Colvin Co is based in the eurozone region and was established ten years ago to manufacture competition standard bicycles for professional road racers. When the company obtained a listing five years ago, the founder retained a small minority shareholding. The remaining shares are held by a number of institutional investors.

The board recently decided to expand the range of models and to look for new growth opportunities abroad. Whilst manufacturing is currently restricted to the eurozone, the board of directors has identified Canvia as a key growth market and is considering a potential investment project to manufacture and sell a new model there. This would involve establishing a subsidiary in Canvia.

### Exhibit 2 — Project information

The currency in Canvia is the Canvian lira (CL) and the current exchange rate is CL9.91 per euro (€). The annual rate of inflation in Canvia is expected to remain at 10% throughout the four-year duration of the project.

The finance director estimates the project’s sales volumes, inflation-adjusted, pre-tax contribution and fixed costs as follows:

| Year | 1 | 2 | 3 | 4 |
|---|---:|---:|---:|---:|
| Sales volume (units) | 109,725 | 121,795 | 148,590 | 197,624 |
| Pre-tax contribution (CLm) | 419.4 | 500.2 | 671.3 | 961.2 |
| Fixed costs (CLm) | 270.0 | 291.6 | 314.9 | 340.1 |

The project will require an immediate investment of CL75m in land and buildings and CL700m in plant and machinery. Tax allowable depreciation is available on plant and machinery on a straight-line basis at an annual rate of 25% on cost. Colvin Co’s finance director believes the plant and machinery will have a zero residual value at the end of the four years. The land and buildings will be disposed of at the end of the project and their tax exempt value is expected to increase at an annual rate of 30% throughout the four-year life of the investment.

The project will also require an immediate investment in working capital of CL25m. The annual incremental working capital requirements are expected to be as follows:

| Year | 0 | 1 | 2 | 3 |
|---|---:|---:|---:|---:|
| CLm | (25.0) | (2.5) | (2.8) | (3.0) |

Working capital will be released back in full at the end of the project. Colvin Co has a policy of extracting remittable cash flows as dividends at the earliest possible opportunity.

All components for the new bicycle will be produced or purchased in Canvia except for a gearing system component which will be manufactured by Colvin Co in the eurozone. The cost of acquiring this component from the eurozone is already included in the pre-tax contribution estimates, based on a transfer price of €10 per component. The finance director estimates a manufacturing cost of €2 per component. Both the transfer price and manufacturing cost are expected to increase in line with eurozone annual inflation of 4% in the first two years of the project and 2% in years three and four.

Corporation tax in Canvia is payable annually at 25% and companies are allowed to carry losses forward to be offset against future trading profits. Colvin Co pays corporation tax in its home country at an annual rate of 20%. Taxes are payable in both countries in the year the liability is incurred. A bi-lateral tax treaty exists between the two countries, which permits the offset of overseas tax against any domestic tax liability incurred on overseas earnings.

### Exhibit 3 — Discount rate

The board proposes financing the project with a mix of equity and debt in such a way that the existing capital structure remains unchanged. For the purposes of this project, the chief executive believes Colvin Co’s weighted average cost of capital of 13% should be adjusted to include a country risk premium on the basis that Canvia is a developing economy and appears to be economically less stable than the eurozone countries. She made this decision after consulting a country risk index, which compares the standard deviation of market returns in various countries. Additional factors taken into consideration include foreign exchange risk, the fact that there have been frequent changes of government, and hence ecomonic policies, in Canvia. You have therefore been asked to use a discount rate of 16% to appraise this investment project.

### Requirements (25 marks)

**(a)** Evaluate the suitability of the investment proposal in Canvia, including the impact of the country risk premium on the net present value of the project. **(14 marks)**

**(b)** Discuss the validity of the chief executive’s reasons for adjusting the discount rate used in appraising the project in Canvia. **(6 marks)**

Professional marks will be awarded for the demonstration of skill in analysis and evaluation, scepticism and commercial acumen in your answer. **(5 marks)**

---

## Question 3 (25 marks)

### Exhibit 1 — Boullain Co and its hedging policy

Boullain Co is based in the Eurozone and manufactures components for agricultural machinery. The company is financed by a combination of debt and equity, having obtained a listing five years ago. In addition to the founder’s equity stake, the shareholders consist of pension funds and other institutional investors. Until recently, sales have been generated exclusively within the Eurozone area but the directors are keen to expand and have identified North America as a key export market. The company recently completed its first sale to a customer based in the United States, although payment will not be received for another six months.

At a recent board meeting, Boullain Co’s finance director argued that the expansion into foreign markets creates the need for a formal hedging policy and that shareholder value would be enhanced if this policy was communicated to the company’s other stakeholders. However, Boullain Co’s chief executive officer disagreed with the finance director on the following grounds. First, existing shareholders are already well diversified and would therefore not benefit from additional risk reduction hedging strategies. Second, there is no obvious benefit to shareholder value by communicating the hedging policy to other stakeholders such as debt providers, employees, customers and suppliers. You have been asked to provide a rationale for the finance director’s comments in advance of the next board meeting.

### Exhibit 2 — Hedging products

Assume today’s date is 1 March 20X0. Boullain Co is due to receive $18,600,000 from the American customer on 31 August 20X0. The finance director is keen to minimise the company’s exposure to foreign exchange risk and has identified forward contracts, exchange traded futures and options as a way of achieving this objective.

The following quotations have been obtained.

#### Exchange rates (quoted as €/US$1)

| Rate | Quotation |
|---|---:|
| Spot | 0.8707–0.8711 |
| Six months forward | 0.8729–0.8744 |

#### Currency futures

Contract size €200,000; price quoted as US$ per €1.

| Contract | Price |
|---|---:|
| March | 1.1476 |
| June | 1.1449 |
| September | 1.1422 |

#### Currency options

Contract size €200,000; exercise price quoted as US$ per €1; premium: US cents per €1.

| Exercise price | March calls | June calls | September calls | March puts | June puts | September puts |
|---:|---:|---:|---:|---:|---:|---:|
| 1.1420 | 0.43 | 0.59 | 0.77 | 0.62 | 0.78 | 0.89 |

Assume futures and options contracts mature at the month end and that there is no basis risk. The number of contracts to be used should be rounded down to the nearest whole number in calculations. If the full amount cannot be hedged using an exact number of futures or options contracts, the balance is hedged using the forward market.

Once the position is open, the euro futures contract outlined above will be marked-to-market on a daily basis. The terms of the contract require Boullain Co to deposit an initial margin per contract with the clearing house. Assume the maintenance margin is equivalent to the initial margin.

Your manager is concerned about the impact of an open futures position on Boullain Co’s cash flow and has asked you to explain the impact of the margin requirements and their significance for the hedging decision.

### Requirements (25 marks)

**(a)** Explain the rationale for the policy of hedging Boullain Co’s foreign exchange risk and the potential benefits to shareholder value if that policy is effectively communicated to the company’s key stakeholders. **(6 marks)**

**(b)** Recommend a hedging strategy for Boullain Co’s foreign currency receipt in six months’ time based on the hedging choices the finance director is considering. Support your recommendation with relevant calculations and appropriate discussion including the impact of the margin requirements. **(14 marks)**

Professional marks will be awarded for the demonstration of skill in analysis and evaluation, scepticism and commercial acumen in your answer. **(5 marks)**
